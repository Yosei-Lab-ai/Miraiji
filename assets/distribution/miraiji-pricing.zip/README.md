# Miraiji /pricing

This self-contained skill is part of Miraiji's implemented three-skill edition.
It has the same functionality and MIT rights as the free source at
https://github.com/Yosei-Lab-ai/Miraiji . No model subscription, API credits,
paid support, future skills or business outcomes are included or guaranteed.
Agent/model provider access, costs and data handling still apply.

For an authorized local copy, keep SKILL.md and references/ together in
~/.claude/skills/pricing/ . Preserve any existing installation and saved files.
For Agensi delivery, follow Agensi's agent-connection instructions.
The three-skill local bundle includes a Bash installer for first install,
non-destructive legacy migration and repeat installation.

Outputs are local under ~/.miraiji/; state/current.md records the unfinished
step and output paths. Before questions, read that state and its outputs.
Your agent may process prompts/files through its provider. Miraiji adds no
telemetry. External actions require the user's separate authorization.

See LICENSE for the MIT notice and warranty disclaimer; retain it on redistribution.
